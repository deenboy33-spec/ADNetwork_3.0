# ADCityCentral Faucet Connector 🏄‍♂️

**Shimly-SMI kompatibler Connector für ADCityCentral.net**

100% ADS-Media kompatibel — für alle Faucet-Systeme, Bonus-Systeme und mehr!

## 🎯 Was ist das?

Dieses Plugin ersetzt **Shimly.de** durch **ADCityCentral.net** und ermöglicht:
- **Auszahlungen** in GSC (GoldSurfer Coins) zu ADCityCentral
- **Einzahlungen** von ADCityCentral zu deinem System
- **100% kompatibel** mit ADS-Media Faucet-Systemen
- **Kostenlos** für alle ADS-Media Nutzer

## 📦 Versionen

### 1. WordPress Plugin (`adcitycentral-faucet.php`)
Für WordPress-basierte Faucet-Systeme:
- Einfache Installation
- Admin-Interface mit Einstellungen
- Shortcode `[adcc_faucet_form]` für Auszahlungsformular
- AJAX-basierte Auszahlungen

### 2. Standalone (`adcitycentral-faucet-standalone.php`)
Für alle anderen Systeme (PHP, Custom, etc.):
- Einfach per `require_once()` einbinden
- Funktionen direkt nutzen
- Kein WordPress nötig

## 🚀 Installation

### WordPress Plugin

1. Datei `adcitycentral-faucet.php` in `/wp-content/plugins/adcitycentral-faucet/` kopieren
2. Plugin im WordPress-Admin aktivieren
3. Menü "ADCityCentral" → Einstellungen öffnen
4. SMI-Zugangsdaten eintragen:
   - **Account:** Dein ADCityCentral SMI-Account
   - **Passwort:** Dein SMI-Passwort
5. Mindestauszahlung: **100.000 GSC** (Standard)

### Standalone (für alle Systeme)

1. Datei `adcitycentral-faucet-standalone.php` auf den Server laden
2. Zugangsdaten in der Datei eintragen (oben bei `ADCC_SMI_ACCOUNT` und `ADCC_SMI_PASSWORD`)
3. In dein System einbinden:

```php
require_once('/pfad/zu/adcitycentral-faucet-standalone.php');

// Auszahlung senden
$result = adcc_send('jogibernd', 100000, 'transfer_passwort', 'Faucet Auszahlung');
if ($result['success']) {
    echo "Erfolg! " . number_format($result['amount'], 0, ',', '.') . " GSC gesendet";
} else {
    echo "Fehler: " . $result['message'];
}

// User validieren
$check = adcc_validate_user('jogibernd', 'transfer_passwort');
if ($check['valid']) {
    echo "User OK, Balance: " . number_format($check['balance'], 0, ',', '.');
}

// User-Guthaben prüfen
$balance = adcc_user_balance('jogibernd', 'transfer_passwort');
if ($balance['success']) {
    echo "Guthaben: " . number_format($balance['balance'], 0, ',', '.') . " GSC";
}

// SMI-Guthaben prüfen (Betreiber)
$saldo = adcc_smi_saldo();
if ($saldo['success']) {
    echo "Dein Guthaben: " . number_format($saldo['smi_balance'], 0, ',', '.') . " GSC";
}
```

## 🔧 Konfiguration

| Option | Standard | Beschreibung |
|--------|----------|-------------|
| SMI Account | leer | Dein ADCityCentral Account |
| SMI Passwort | leer | Dein SMI-Passwort |
| Exchange Rate | 1.0 | 1:1 für GSC (1000 Punkte = 1000 GSC) |
| Min. Auszahlung | 100.000 | Mindestbetrag in GSC |
| Max. Auszahlung | 10.000.000 | Maximalbetrag in GSC (0 = unbegrenzt) |
| Min. Einzahlung | 0 | Mindestbetrag für Einzahlungen |
| Basis-Gebühr | 0 | Gebühr pro Transaktion |
| Trust Level | 0 | Vertrauensstufe |
| Tägliche Anfragen | 0 | Limit (0 = unbegrenzt) |
| Extra-Gebühr | 0 | Gebühr bei Überlimit |

## 📡 API-Format

Kompatibel mit Shimly-SMI (pipe-delimited):

```
1001|OK|BALANCE|TRANSAKTIONS_ID|USER_BALANCE|0|0 = Erfolg
1002|FEHLER|0|0|0|0|0 = Fehler
```

## 🌐 API-Endpoints

| Endpoint | Beschreibung |
|----------|-------------|
| `send.php` | Auszahlung senden |
| `get.php` | Einzahlung empfangen |
| `saldo.php` | User-Guthaben prüfen |
| `validate.php` | User validieren |
| `smi_saldo.php` | SMI-Guthaben prüfen |

**API-URL:** `https://adcitycentral.net/ngm-external/shimlys/`

## 🔐 Sicherheit

- **Transfer-Passwort** wird für jede Auszahlung benötigt
- **SSL-Verbindung** (HTTPS) auf Serverseite
- **IP-Validierung** optional
- **Transaktionscodes** für Nachverfolgung

## 🧪 Testen

```bash
# CLI-Test
php adcitycentral-faucet-standalone.php

# Oder via Browser
https://deine-domain.de/adcitycentral-faucet-standalone.php?adcc_test=1
```

## 📋 Fehlercodes

| Code | Bedeutung |
|------|-----------|
| 1001 | OK |
| 1002 | SMI Account existiert nicht |
| 1003 | SMI Passwort falsch |
| 1004 | Nicht genug freie Anfragen |
| 1005 | SMI Kennung existiert nicht |
| 1006 | Shimly User existiert nicht |
| 1007 | Shimly User gesperrt |
| 1008 | Shimly User zu geringer Kontostand |
| 1009 | Shimly User SMI Passwort falsch |
| 1010 | SMI Account zu geringer Kontostand |
| 1011 | Ungültiger Buchungsbetrag |
| 1012 | Betreff nicht zulässig |
| 1050 | Ungültige IP-Adresse |
| 1095 | SMI im Wartungsmodus |
| 1097 | SMI überlastet |
| 1098 | SMI Account gesperrt |
| 1099 | Unbekannter Fehler |

## 📝 Beispiel-Integration

### In einem Faucet-System:

```php
// config.php
require_once('adcitycentral-faucet-standalone.php');

// payout.php
if ($user_balance >= 100000) {
    $result = adcc_send(
        $user->adcc_username,    // ADCityCentral Username
        $user_balance,           // Betrag in GSC
        $user->adcc_password,    // Transfer-Passwort
        'Faucet Auszahlung'      // Betreff
    );
    
    if ($result['success']) {
        // User-Guthaben zurücksetzen
        $user->balance = 0;
        echo "Auszahlung erfolgreich!";
    } else {
        echo "Fehler: " . $result['message'];
    }
}
```

### In WordPress (mit Shortcode):

```php
// In einer Seite oder einem Widget:
[adcc_faucet_form]
```

Dies zeigt ein Formular mit:
- ADCityCentral Username
- Transfer-Passwort
- Betrag
- Auszahlungs-Button

## 🎓 Für Entwickler

### Custom Integration:

```php
// Eigene Konfiguration
define('ADCC_API_BASE', 'https://adcitycentral.net/ngm-external/shimlys/');
define('ADCC_SMI_ACCOUNT', 'mein-account');
define('ADCC_SMI_PASSWORD', 'mein-passwort');

require_once('adcitycentral-faucet-standalone.php');

// Custom Logik
function my_custom_payout($user_id, $amount) {
    $user = get_user($user_id);
    return adcc_send($user->adcc_name, $amount, $user->adcc_tpw);
}
```

## 🤝 Unterstützte Systeme

- ✅ ADS-Media Faucet-Systeme
- ✅ WordPress + WooCommerce
- ✅ Custom PHP-Systeme
- ✅ Bonus-Systeme
- ✅ Reward-Systeme
- ✅ Alle Shimly-SMI kompatiblen Systeme

## 🆓 Kostenlos

Dieses Plugin ist **kostenlos** für alle ADS-Media Nutzer und deren Partner.

## 📞 Support

Bei Fragen oder Problemen:
- GoldSurfer 🏄‍♂️ für Bernd
- ADCityCentral.net

## 📜 Changelog

**1.0.0** (2026-06-14)
- Erste Version
- Shimly-SMI kompatibel
- GSC-Transfer zu ADCityCentral.net
- WordPress Plugin + Standalone-Version
- 100% ADS-Media kompatibel

## 🏄‍♂️ Viel Spaß!

GoldSurfer für Bernd
